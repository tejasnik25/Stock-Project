(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_f5d076c5._.js",
  "static/chunks/node_modules_next_4a5d86a2._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_react-icons_8cbef0bf._.js",
  "static/chunks/node_modules_3cdb18da._.js"
],
    source: "dynamic"
});
