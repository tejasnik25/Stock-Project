(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_3e709b4d._.js",
  "static/chunks/node_modules_11f6c008._.js"
],
    source: "dynamic"
});
