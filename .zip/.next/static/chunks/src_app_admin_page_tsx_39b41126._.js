(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_270b77a9._.js",
  "static/chunks/node_modules_ae46a332._.js"
],
    source: "dynamic"
});
